#!/usr/bin/python
import sys
from PIL import Image, ImageDraw, ImageFont
import PIL.ImageOps

f = open("/tmp/input.txt")

fontsize = 45
font = ImageFont.truetype( \
	 "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", fontsize )
im = Image.new( "RGB", (612,300) )
draw = ImageDraw.Draw( im )
start_loc = 80
## draw.text( (90,  start_loc), "SP15-999999", font=font )
## thisString = "SP15-999999"
def	texting(thisString):
	global start_loc
	for i in range(0, len(thisString)):
		draw.text( (90+ i*(fontsize*7/10), start_loc), thisString[i], font=font)
	start_loc = start_loc + 32 + 16			# indexing to next pos.

## texting("SP15-999999")
## texting (sys.argv[1])	## line 1
texting(f.readline())

##start_loc = start_loc + 32 + 16
## texting("SMITH MARY")
## if sys.argv[2] 
## texting (sys.argv[2])	## line 2
texting(f.readline())

## draw.text( (90,  start_loc), "SMITH MARY" , font=font )  

##start_loc = start_loc + 32 + 16
## draw.text( (90,  start_loc), "A1" , font=font )  

## texting("A1")
## texting (sys.argv[3])	## line 3
texting(f.readline())

# now drawing the starting bar
for i in range(0, 60):
	draw.line( (i,76,  i, 223), fill =(255,255,255))



barcode2d = Image.open("/tmp/barcode2D.png").convert('RGB')
## pixels = barcode2d.load()
##for x in range(0, barcode2d.size[0]):
##	for y in range(0, barcode2d.size[1]):
##		## (r,g,b) = pixels[x,y]
##		pixels[x,y] = (255-r, 255-g, 255-b)


inv_barcode2d = PIL.ImageOps.invert(barcode2d)
im.paste(inv_barcode2d, (472, 85))

im.save( "/tmp/text.png" )	## so, it is loseless.
## im.show()

sys.exit(0)
##if __name__ == "__main__":
##	main()
