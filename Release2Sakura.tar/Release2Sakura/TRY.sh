echo "SP-15-999999" > /tmp/input.txt
echo "SMITH MARY" >> /tmp/input.txt
echo "A1"    >> /tmp/input.txt
python execute_program.py
echo "Now you could see what you want"
gpicview /tmp/text.png

